#!/bin/bash

# 定义下载链接和目标文件名
DOWNLOAD_URL="https://box.cse.hust.edu.cn/seafhttp/f/20299c87d30347afaee2/?op=view"
OUTPUT_FILENAME="image.tar.gz"
CURRENT_PATH="." # 当前路径

# 确保脚本在发生错误时退出
set -e

echo "开始下载文件..."

# 1. 下载文件，重命名并存放到当前路径
# 使用 curl 命令，-L 选项用于跟踪重定向，-o 选项用于指定输出文件名
curl -L -o "${CURRENT_PATH}/${OUTPUT_FILENAME}" "${DOWNLOAD_URL}"

if [ $? -eq 0 ]; then
  echo "文件 ${OUTPUT_FILENAME} 下载成功，已保存到当前路径。"
else
  echo "文件下载失败！请检查链接或网络连接。"
  exit 1
fi

echo "开始解压文件 ${OUTPUT_FILENAME}..."

# 2. 解压文件到当前路径 (并保留原文件)
# tar 命令的 -x 参数表示解压，-v 表示显示详细过程，-z 表示处理 .gz 压缩文件，-f 指定文件名
# tar 命令默认在解压时会保留原始压缩文件
tar -xf "${CURRENT_PATH}/${OUTPUT_FILENAME}" -C "${CURRENT_PATH}"

if [ $? -eq 0 ]; then
  echo "文件 ${OUTPUT_FILENAME} 解压成功，已解压到当前路径。"
  echo "原始文件 ${OUTPUT_FILENAME} 已保留。"
else
  echo "文件解压失败！"
  exit 1
fi

echo "所有操作完成。"
exit 0