# Linux kernel exploitation experiments

__Contents:__
  - __chall3_maze_mod.c__ - a small Linux kernel module with vulnerability.
  - __maze_exploit_dirtypipe.c__ - a basic pipe primitive exploit
  - __bzImage__ - Linux kernel x86 boot executable bzImage compiled with 5.10.202
  - __config-5.10.202__ - the .config file of linux 5.10.202
  - __rootfs.cpio__ - the file system for qemu vm
  - __run.sh__ - the script to run a qemu vm
  - __fs.sh__ - the script to repack the rootfs.cpio
  - __flag__ - a test flag
  - __upload.py__ - the script to upload exploit to remote challenge 

Have fun!

## Preparation

### 1. Compile Linux Kernel


* If you do not want to compile kernel by yourself, just use the *`bzImage`* in attachments and pass this part.
* Preferably build on Ubuntu 20.04 or docker to reduce compile issues
```
wget https://cdn.kernel.org/pub/linux/kernel/v5.x/linux-5.10.202.tar.xz
tar -xvf linux-5.10.202.tar.xz
cd linux-5.10.202
cp ../config-5.10.202 .config
make olddefconfig
make -j32 CC=gcc-8
```
Create soft link with the target Linux kernel in case you have multiple Linux kernel versions, then use the `bzImage` in `$PWD/linux/arch/x86/boot/bzImage`
```
ln -s linux-5.10.202 linux
```

### 2. Exploitation

[pipe primitive][3] originated from the [exploitation][2] of [CVE-2022-0847][1]

Linux 内核申请 pipe 结构体时会默认分配 kmalloc-1024 大小的 pipe_buffer 对象，且 splice 系统调用可以将 pipe 与文件连接在一起，相当于 pipe_buffer->page = fd->page 。当 pipe_buffer->flags 为 PIPE_BUF_FLAG_CAN_MERGE 时，可以绕过页面权限检查，往 pipe_buffer->page 追加续写内容，从而实现对只读文件的任何写操作。仅需利用 UAF 漏洞改写 pipe_buffer->flags 为 PIPE_BUF_FLAG_CAN_MERGE，即可实现权限提升。

#### Mitigation Enable
- `CONFIG_SLUB_DEBUG=y`
- `CONFIG_SLUB=y`
- `CONFIG_SLAB_MERGE_DEFAULT=y`
- `CONFIG_SLUB_CPU_PARTIAL=y`
- `CONFIG_RANDOMIZE_BASE=y`
- `CONFIG_X86_SMAP=y`
- `CONFIG_PAGE_TABLE_ISOLATION=y`

#### Mitigation Disable
- `CONFIG_SLAB is not set`
- `CONFIG_SLAB_FREELIST_RANDOM is not set`
- `CONFIG_SLAB_FREELIST_HARDENED is not set`
- `CONFIG_MEMCG is not set`
- `CONFIG_DEBUG_LIST is not set`


### 3. Patch The Vulnerable Module And Recompile
- Patch the vulnerability in `vulnerability module`. 
- Recompile it and repack into `rootfs.cpio`.
- Redo the `pipe primitive` exploit and this exploit does not work any more

---


<!-- ## Reference -->
[1]: https://dirtypipe.cm4all.com/
[2]: https://github.com/AlexisAhmed/CVE-2022-0847-DirtyPipe-Exploits
[3]: https://github.com/veritas501/pipe-primitive
