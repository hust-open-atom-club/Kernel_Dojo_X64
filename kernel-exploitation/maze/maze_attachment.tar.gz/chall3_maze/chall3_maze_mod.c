/*
 * One Kernel Module for Kernel Exploitment Experiments
 */

#include <linux/module.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/string.h>
#include <linux/miscdevice.h>

#define ACT_SIZE 5
#define MAZE_BUF_SIZE 0x400

enum maze_act_t {
	MAZE_ACT_NONE = 0x40000,
	MAZE_ACT_ALLOC = 0x40001,
	MAZE_ACT_EDIT = 0x40002,
	MAZE_ACT_FREE = 0x40003,
	MAZE_ACT_RESET = 0x40004
};

struct maze_t {
	struct dentry *dir;
	char * buf;
};

struct user_maze_t {
	char * buffer;
	size_t offset;
};

static struct maze_t maze; /* initialized by zeros */

static long maze_act_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	ssize_t ret = 0;
	struct user_maze_t user_maze;

	switch (cmd) {
	case MAZE_ACT_ALLOC:
		maze.buf = kmalloc(MAZE_BUF_SIZE, GFP_KERNEL_ACCOUNT);
		if (maze.buf == NULL) {
			pr_err("maze: not enough memory for item\n");
			ret = -ENOMEM;
			break;
		}

		pr_notice("maze: kmalloc'ed buf at %lx (size %d)\n",
				(unsigned long)maze.buf, MAZE_BUF_SIZE);

		break;

	case MAZE_ACT_EDIT:
		if (copy_from_user(&user_maze, (void*)arg, sizeof(struct user_maze_t))) {
			pr_err("maze: copy_from_user failed\n");
			ret = -ENOMEM;
			break;
		}
		
		if (user_maze.buffer == NULL || user_maze.offset > MAZE_BUF_SIZE - 1) {
			pr_err("maze edit offset too big\n");
			ret = -ENOMEM;
		} 

		pr_notice("maze: edit %lx at offset %lx\n", (unsigned long)maze.buf, user_maze.offset);
		if (copy_from_user(maze.buf + user_maze.offset, user_maze.buffer, 1)) {
			pr_err("maze edit failed\n");
			ret = -ENOMEM;	
		}; 
		break;

	case MAZE_ACT_FREE:
		pr_notice("maze: free buf at %lx\n",
					(unsigned long)maze.buf);
		kfree(maze.buf);
		break;

	case MAZE_ACT_RESET:
		maze.buf = NULL;
		pr_notice("maze: set buf ptr to NULL\n");
		break;

	default:
		pr_err("maze: invalid act %d\n", cmd);
		ret = -EINVAL;
		break;
	}

	return ret;
}

static const struct file_operations maze_act_fops = {
	.unlocked_ioctl = maze_act_ioctl,
};

static struct miscdevice misc = {
    .minor = MISC_DYNAMIC_MINOR,
    .name  = "maze",
    .fops = &maze_act_fops
};

int maze_init(void)
{
	printk(KERN_INFO "Welcome to kernel challenge3 maze\n");
	misc_register(&misc);
	return 0;
}

void maze_exit(void)
{
	printk(KERN_INFO "Goodbye hacker\n");
	misc_deregister(&misc);
}

module_init(maze_init)
module_exit(maze_exit)

MODULE_AUTHOR("Dongliang Mu <dzm91@hust.edu.cn>");
MODULE_DESCRIPTION("One Kernel Module for Kernel Exploitment Experiments");
MODULE_LICENSE("GPL v2");
